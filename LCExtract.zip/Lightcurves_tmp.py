# LCExtrac
from LCExtract import *

# https://docs.lightkurve.org/
# https://docs.lightkurve.org/tutorials/
# https://docs.lightkurve.org/reference/api/lightkurve.KeplerTargetPixelFile.html

'''=============================================================================
IMPROVEMENTS

- Que se use una formula para que en función del tamaño de la estrella contaminante
se seleccionen X pixeles aledaños y se quiten de la mask_new pasando a mask_cont (por ejem)

- Que se exporte los resultados de LC, PG, Mag, masks como extensiones de un FITS file
que luego se puedan subir a MESA.

- Que la parte de saturación se haga con un cut en Flux counts no con un sigma del pixel
central y que se tenga en cuenta todos los frames de la LC

============================================================================='''

ID = 'HD192422'
ID = 'HD46328'
ID = 'HD92850'
ID = 'HD152590'
ID = 'HD13659'

'''=============================================================================
        TPF o LC
============================================================================='''

tpf_0 = query_data(ID, method='tesscut', mission='TESS', author='any', cadence=None, sec=None, cutout_size=20)
# or
tpf_0 = query_data(ID, method='tpf', mission='TESS', author='any', cadence=None, sec=None)
#or
lc_1 = query_data(ID, method='simple', mission='TESS', author='any', cadence=None, sec=None)

'''=============================================================================
        Gaia contaminants (hacer antes o después de aperture mask)
============================================================================='''

contaminants(tpf_0, mask='pipeline', dmag=6)
contaminants(tpf_0, mask='mask_new', dmag=6)

'''=============================================================================
        APERTURE MASK
============================================================================='''

tpf_1 = change_aperture(tpf_0, ini_mask='pipeline', method='basic', sky_cut=0.01)
# or
tpf_1 = change_aperture(tpf_0, ini_mask='pipeline', method='threshold', sky_cut=0.01, sat_cut=1000)

# refinar la aperture mask
tpf_1 = change_aperture(tpf_0, ini_mask='new', method='basic', sky_cut=0.01)

'''=============================================================================
        LIGHT CURVE DETRENDING AND EXPORT
============================================================================='''

lc_0 = tpf_to_lc(tpf_1, mask='new')

lc_1 = detrended_tpf_to_lc(lc_0, tpf_1, tpf_1.mask_background)

lc_1 = lc_1[[(i > 1571.1) for i in lc_1.time.value]]
lc_1 = lc_1[[(i > 1720) & (i < 1723)  for i in lc_1.time.value]]
lc_1 = lc_1[[(i < 1801) | (i > 1804)  for i in lc_1.time.value]]

lc_2 = sig_clip_lc(lc_1, sigma=3.2)

export_lc(lc_2)

'''=============================================================================
        PERIDIOGRAM
============================================================================='''
#----------
# SHORTCUT FOR TESTING
from LCExtract import *
ID = 'HD13659'
lc_2 = query_data(ID, method='simple', mission='TESS', author=None)
lc_2 = get_mag_lc(lc_2)
#----------

pg = lc_to_perid(lc_2, oversample_factor=5, dcut=0.2, y_axis='power')
pg = lc_to_perid(lc_2, oversample_factor=5, dcut=0.2, y_axis='mag', norm=True) 
# Use the above specially if the 'simple' method is used for quering the LC

'''=============================================================================
        EXPORT PERIDIOGRAM AND DO STATS
============================================================================='''
export_pg(pg); stats(lc_2,pg)


'''================================== END ==================================='''

## THE MESS WITH THE UNITS THAT I STILL NEED TO UNDERSTAND AND FIX
#pg = lc_2.to_periodogram(method='lombscargle', oversample_factor=5)
#pg.magnitude = 1e6*(((pg.power - np.median(pg.power)) / np.median(pg.power))/pg.frequency)
#pg.magnitude = 1e-1*((pg.power - np.median(pg.power)) / np.median(pg.power))
#fig_pg, ax_pg = plt.subplots(figsize=(7,3.5))
#ax_pg.plot(pg.frequency, pg.magnitude, lw=.5)
#ax_pg.set_xlim(0,4); ax_pg.set_ylim(0,);
#plt.show()

from astropy.stats import freedman_bin_width

lc_std = lc_pp = []
for i in range(1000):
    sample = np.asarray(random.sample(lc_2.magnitude.tolist(), int(0.75*len(lc_2))))
    #lc_std.append(sample.std())
    lc_pp.append(1000*abs(sample.min()-sample.max()))

lc_pp_sc = sigmaclip(lc_pp, low=2., high=2.)[0].mean()

1000*lc_2.magnitude.std()

width = int(freedman_bin_width(lc_pp))
plt.hist(lc_pp, bins=range(int(min(lc_pp)), int(max(lc_pp)) + width, width))
plt.show()

from scipy.stats import sigmaclip as sc
lc_pp_sc = sc(lc_pp, low=2., high=2.)[0]
width = int(freedman_bin_width(lc_pp_sc))
plt.hist(lc_pp_sc)
plt.show()
print(len(lc_pp),len(lc_pp_sc))

plt.plot(lc_2.time.value,1000*lc_2.magnitude); plt.show()

# MANUAAAAL
pg = lc_2.to_periodogram(method='lombscargle', oversample_factor=4)

magnitude = 1e-2*((pg.power - np.median(pg.power)) / np.median(pg.power))
#magnitude = 1e6*((lc_2.flux - np.median(lc_2.flux)) / np.median(lc_2.flux))

fig, ax = plt.subplots(figsize=(5,2))
ax.plot(pg.frequency, pg.magnitude, lw=.5)
pg.plot(ax=ax, view='frequency', scale='linear', xlabel=r'Freq. [d$^{-1}$]')
#ax.set_ylim([0,2.5*1e8])
ax.set_xlim([0,15])
ax.set_xlabel(r'Freq. [d$^{-1}$]')
ax.set_ylabel('Amp. (mmag)')
plt.show()

pg.show_properties()
pg.plot(view='frequency', scale='linear', xlabel=r'Freq. [d$^{-1}$]')
plt.show()
type(pg)



'''=============================================================================
        LC Leuven
============================================================================='''

import sys
sys.path.append('../pyIACOB/')
sys.path.append('/Users/abelink/MEGA/PhD/programs/python/pyIACOB/edr3_zp')

'/Users/abelink/MEGA/PhD/programs/python/pyIACOB/'
from db import *

mist = findtable('mist_points.fits')
mist['Teff'] = 10**mist['log_Teff']

T_DB = findtable('IACOB_O9BAs_SNR20.fits') # file where main information and quality flags are
T_REF = findtable('RVEWFWs.fits') # file where RVs, EWs and FWs are
T_IB = findtable('IB_results.fits') # file where vsini and vmac are
T_IB.remove_columns(['line_IB','SNR_IB'])
T_MAUI = findtable('MAUI_results_all_SGs+Gs_HeSi.fits', path='/Users/abelink/MEGA/PhD/BsPhD/MAUI/Tables&PDFs/')

# LOAD THE GOOGLE SPREADSHEET TABLE
T_gs = findtable('maui_google.csv')
if 'Comments' in T_gs.colnames: T_gs.remove_column('Comments')

# ADD A COLUMN WITH THE QUALITY (COLOR/CODE)
c = []
for i in T_gs:
    if i['V'] == 'TRUE': c.append('g')
    elif i['X'] == 'TRUE': c.append('r')
    else: c.append('orange')
T_gs['color'] = c

T_MAUI['Teff'] = T_MAUI['Teff']*1e4

#                               FILTERS TO THE TABLE
#T_MAUI = T_MAUI[[str(i['Teff'])!='nan' and str(i['lgf'])!='nan' for i in T_MAUI]]
T_MAUI = T_MAUI[[i not in ['d','<','>'] and j not in ['d','<','>'] for i,j in T_MAUI['l_Teff','l_lgf']]]

#                               ADD DATA TO THE MASTER TABLE
T = join(T_MAUI, T_REF, keys='ID')
T = join(T, T_IB, keys='ID')

T['color'] = [T_gs[T_gs['ID'] == i]['color'][0] for i in T['ID']] # Color
T['wind'] = [T_gs[T_gs['ID'] == i]['C Ha'][0] for i in T['ID']] # Wind

T_Gon = findtable('IB+GBAT_Os_GS.fits') # Table with all IB+GBAT result from stars in GS
T_Gon = T_Gon[T_Gon['Ref']=='PhD']
T_Gon['Teff'] = T_Gon['Teff']*1e4
T_Gon.rename_columns(['vsini_G','vmac_G'],['vsini_GF','vmac_GF'])

T_i = T[(T['color'] == 'g') | (T['color'] == 'orange')]
T_i = T_i[T_i['He']<0.12]
T_i = T_i[T_i['vsini_GF']<140]

T_1 = T_i[[i in ['HD92850','HD68450','HD36486','HD152147'] for i in T_i['ID']]] # UP LEFT
T_2 = T_i[[i in ['HD15785','HD163522','HD190066','HD91316','HD48434','HD192422'] for i in T_i['ID']]] # UP LEFT 2
T_3 = T_i[[i in ['HD193076','HD42379', 'HD190919','HD194057', 'HD54764'] for i in T_i['ID']]] # DOWN LEFT
T_4 = T_i[[i in ['HD119646','HD15690','HD164032','HD214080'] for i in T_i['ID']]] # DOWN RIGHT
T_5 = T_i[[i in ['HD13841','HD13854','HD14818','HD41398','HD99953'] for i in T_i['ID']]] # HE RICH
T_6 = T_i[[i in ['HD79186','HD102997','HD198478','HD60308','HD75149'] for i in T_i['ID']]] # UP RIGHT

# T_1 NO: HD167264[NODATA], HD152405[BAD], HD101545A[BINARY]
# T_2 NO: HD2905[BAD]
# T_3 NO: HD167287[NODATA], HD171432[NODATA], HD215733[NODATA], BD+353955[CONTAMI]
# T_4 NO: HD14443[CONTAMI]
# T_6 NO: HD167838[NODATA], HD53138[BRIGHT],

T_T = vstack([T_1,T_2,T_3,T_4,T_5,T_6])

T_CNO=findtable('ANALYSIS.ABEL_2022_TESS_HHeSi_CNO_results_.txt', path='/Users/abelink/MEGA/PhD/programs/python/LCExtractor/DATA/')
T_CNO['lgf'] =  T_CNO['logg'] - 4*np.log10(T_CNO['Teff']*10**4) + 16
T_CNO['Teff'] = T_CNO['Teff']*1e4

NO_ref = (10**(7.79-12)/10**(8.76-12))
NC_ref = (10**(7.79-12)/10**(8.35-12))
np.log10(NC_ref)

T_CNO['N/O'] = ((10**(T_CNO['N']-12))/(10**(T_CNO['O']-12)))/NO_ref
T_CNO['N/C'] = ((10**(T_CNO['N']-12))/(10**(T_CNO['C']-12)))/NC_ref
T_CNO['ID'] = [i.split('_')[0] for i in T_CNO['Ref_file']]

C=8.35
N=7.79
O=8.76

T_j = T_i[(T_i['Teff']<32000) & (5.39-T_i['lgf']<4.205) & (5.39-T_i['lgf']>4) & (T_i['Si']<7.7) & (T_i['Si']>7.2)]
T_j = T_j[[i not in T_T['ID'] for i in T_j['ID']]]

T_j.show_in_browser(jsviewer=True)
T_j.sort('color')


def sHR_All(T_i, param, color, wind=None, quality=False, T_j=None, Gon=None, size=0):
    fig = plt.figure(figsize=(7,6)) #8,7 / 6,8
    fig.tight_layout()
    gs = fig.add_gridspec(4, 4, hspace=0.1, wspace=0.1)
    ax = fig.add_subplot(gs[:-1,:-1])
    ax_r = fig.add_subplot(gs[:-1,3], sharey=ax)
    ax_b = fig.add_subplot(gs[-1,:-1], sharex=ax)

    ax_top = ax.twiny()

    ax.xaxis.set_minor_locator(AutoMinorLocator())
    ax.yaxis.set_minor_locator(AutoMinorLocator())

    ax.tick_params(direction='in', top='on', right='on', which='major', length=6, color='k', labelbottom=False)
    ax.tick_params(direction='in', top='on', right='on', which='minor', length=3, color='k')

    ax.set_ylabel(r"log($\mathcal{L}$/$\mathcal{L}_{\odot}$)", size=12)

    ax.set_xlim(4.56, 4.13)
    #ax.set_xlim(4.5,3.7) # TMP

    ax.set_ylim(3.3,4.5)
    #ax.set_ylim(3.8,4.5) # TMP

    ax_r.xaxis.set_minor_locator(AutoMinorLocator())
    ax_b.yaxis.set_minor_locator(AutoMinorLocator())

    ax_r.yaxis.set_label_position("right")
    ax_r.yaxis.set_ticks_position("right")
    ax_r.xaxis.set_label_position("top")

    ax_b.tick_params(direction='in', top='on', right='on', which='both')
    ax_r.tick_params(direction='in', top='on', left='on', right='on', which='both')

    ax_r.set_xlabel(param, size=12)
    ax_b.set_ylabel(param, size=12)

    #ax_b.set_ylabel(r'$\dfrac{(Ν/C)}{(Ν/C)_{ref}}$', size=10)
    ax_b.set_ylabel('N(He)/N(H)', size=10)

    ax_r.set_ylabel(r"log($\mathcal{L}$/$\mathcal{L}_{\odot}$)", size=12)
    ax_b.set_xlabel(r"log(T$_{eff})\,$[K]", size=12)

    ax_top.tick_params(direction='in', top='off')
    ax_top.set_xlim(ax.get_xlim())
    ax_top.set_xticks(ax.get_xticks()[1:-1])
    ax_top.set_xticklabels([round(10**i/100)*100 for i in ax.get_xticks()[1:-1]], fontsize=9)
    ax_top.set_xlabel(r"T$_{eff}\,$[K]", size=12, labelpad=13)

    # Data to plot - Main figure
    ax.scatter(mist['log_Teff'],mist['log_Lspec'], s=.3, color='gray', alpha=.3)
    ax.plot([4.146,4.543,4.543,4.146,4.146],[3.54,3.54,4.394,4.394,3.54], '--', c='k', lw=.5)
    ax.plot([4.204,4.543,4.543,4.204,4.204],[2.937,2.937,3.791,3.791,2.937], '--', c='k', lw=.5)

    # Plot Gonzalo's results
    if Gon is not None:
        ax.scatter(np.log10(T_Gon['Teff']), 5.39-T_Gon['lgf'], s=15,
            c='gray', ec='None', marker='o', alpha=.5)

    if color not in T_i.colnames:  c = color
    else:  c = T_i[color]

    # WIND SUB-TABLE
    if wind != None:
        if wind in ['Em+','PCy','DP','CF++']:
            T_w = T_i[[wind in i for i in T_i['wind']]]
        elif wind == 'Qs':
            T_w = T_i[T_i['logQs'] > -13]
        elif wind == 'flags':
            T_w = T_i[any([j in T_i['wind'] for j in ['Em+','PCy','DP','CF++']])]
        elif wind == 'both':
            T_w = T_i[[((j['logQs'] > -13) or (any([k in j['wind'] for k in ['Em+','PCy','DP','CF++']]))) for j in T_i]]
        if color not in T_w.colnames:  c_w = color
        else:  c_w = T_w[color]

    # -----------------------------------------------------------------------------------
    # Data to plot - Main figure
    im = ax.scatter(np.log10(T_i['Teff']), 5.39-T_i['lgf'], s=15+size,
        c=c, ec='None', marker='o', cmap='gnuplot')

    if wind != None:
        ax.scatter(np.log10(T_w['Teff']), 5.39-T_w['lgf'], s=45,
            c=c_w, ec='None', marker='*', cmap='gnuplot', alpha=.8)

    if quality == True:
        ax.scatter(np.log10(T_i['Teff']), 5.39-T_i['lgf'], s=25,
            c=T_i['color'], ec='None', marker='o', zorder=0)

    if T_j is not None:
        ax.scatter(np.log10(T_j['Teff']), 5.39-T_j['lgf'], s=15,
            c='gray', ec='None', marker='o', zorder=0)

    if color in T_i.colnames:
        cbar = fig.add_axes([0.74, -0.03, 0.02, 0.30])
        fig.colorbar(im, cax=cbar, label=color)

    # -----------------------------------------------------------------------------------
    # Data to plot - Right figure
    ax_r.scatter(T_i[param], 5.39-T_i['lgf'], s=15+size,
        c=c, ec='None', marker='o', cmap='gnuplot')

    if wind != None:
        ax_r.scatter(T_w[param], 5.39-T_w['lgf'], s=45,
            c=c_w, ec='None', marker='*', cmap='gnuplot', alpha=.8)

    if quality == True:
        ax_r.scatter(T_i[param], 5.39-T_i['lgf'], s=25,
            c=T_i['color'], ec='None', marker='o', zorder=0)

    #if T_j is not None:
    #    ax_r.scatter(T_j[param], 5.39-T_j['lgf'], s=15,
    #        c='gray', ec='None', marker='o', zorder=0)

    # -----------------------------------------------------------------------------------
    # Data to plot - Bottom figure
    ax_b.scatter(np.log10(T_i['Teff']), T_i[param], s=15+size,
        c=c, ec='None', marker='o', cmap='gnuplot')
    if wind != None:
        ax_b.scatter(np.log10(T_w['Teff']), T_w[param], s=45,
            c=c_w, ec='None', marker='*', cmap='gnuplot', alpha=.8)

    if quality == True:
        ax_b.scatter(np.log10(T_i['Teff']), T_i[param], s=25,
            c=T_i['color'], ec='None', marker='o', zorder=0)

    #if T_j is not None:
    #    ax_b.scatter(np.log10(T_j['Teff']), T_j[param], s=15,
    #        c='gray', ec='None', marker='o', zorder=0)

    # -----------------------------------------------------------------------------------

    fig.savefig('/Users/abelink/MEGA/PhD/programs/python/LCExtractor/ALL_PLOTS/sHRD__.png', format='png', dpi=300, bbox_inches='tight')

    plt.show()

T_j = T_i[[i in ['BD+353955', 'HD190919', 'HD194057', 'HD54764'] for i in T_i['ID']]]
T_j = T_i[T_i['ID']=='HD36486']

sHR_All(T_i=T_T, param='He', color='He', wind=None, quality=False, T_j=T_i, Gon=T_Gon, size=35)


'''=============================================================================
        Fig. Hist He
============================================================================='''
T_He = T[(T['color'] == 'g') | (T['color'] == 'orange')]
T_He = T_He[(T_He['He'] < 0.24)]

fig, ax = plt.subplots(figsize=(6,2))
fig.tight_layout()
ax.set_xlabel('N(He)/N(H)')
ax.set_ylabel(r'# stars')

#im  = ax.scatter(T_CNO['He'], T_CNO['N/O'], c=T_CNO['Teff'], s=100, cmap='gnuplot_r')
ax.hist(T_He['He'], bins=np.linspace(0.1,0.2,21), color='orange', ec='k')
ax.axvline(T_He['He'].std()+T_He['He'].mean(), c='k')
fig.savefig('/Users/abelink/MEGA/PhD/programs/python/LCExtractor/ALL_PLOTS/Hist_He.png', format='png', dpi=300, bbox_inches='tight')

plt.show()


'''=============================================================================
        Figs. CNO abundances
============================================================================='''

T_CNO['He_Ab'] = [T_T['He'][T_T['ID']==i] for i in T_CNO['ID']]
fig, ax = plt.subplots(figsize=(6,3))
fig.tight_layout()
ax.set_xlabel('He')
ax.set_ylabel('N/O')

#im  = ax.scatter(T_CNO['He'], T_CNO['N/O'], c=T_CNO['Teff'], s=100, cmap='gnuplot_r')
im  = ax.scatter(T_CNO['He_Ab'], T_CNO['N/O'], c=T_CNO['Teff'], s=100, cmap='gnuplot_r')
fig.colorbar(im, label='Teff [K]', pad=0.01)
fig.savefig('/Users/abelink/MEGA/PhD/programs/python/LCExtractor/ALL_PLOTS/NO_vs_He.png', format='png', dpi=300, bbox_inches='tight')

plt.show()

#--------------------------------------------------------------------

fig, ax = plt.subplots(figsize=(6,4))
fig.tight_layout()
ax.set_ylabel(r'$\dfrac{(Ν/C)}{(Ν/C)_{ref}}$', size=12)
ax.set_xlabel(r'$\dfrac{(Ν/O)}{(Ν/O)_{ref}}$', size=12)

im  = ax.scatter(T_CNO['N/O'], T_CNO['N/C'], c=T_CNO['Teff'], s=100, cmap='gnuplot_r')
#cbar = fig.add_axes([0.8, 0.15, 0.03, 0.5])
fig.colorbar(im, label='Teff [K]', pad=0.01)
fig.savefig('/Users/abelink/MEGA/PhD/programs/python/LCExtractor/ALL_PLOTS/NC_vs_NO.png', format='png', dpi=300, bbox_inches='tight')

plt.show()


'''=============================================================================
        Copy plots
============================================================================='''
import shutil
len(T_T['ID'])
for name in T_T['ID']:
    found = False
    for root, dirs, files in os.walk('/Users/abelink/MEGA/PhD/programs/python/LCExtractor/DATA/'):
        for file in files:
            if file == name+'_periodogram_mag.png':
                found = True
                f_dir = os.path.join(root, file)
                #shutil.copyfile(f_dir, '/Users/abelink/MEGA/PhD/programs/python/LCExtractor/ALL_PLOTS/PG/'+file)
    if found == False:
        print(name)


'''=============================================================================
        Fig. freq vs Teff
============================================================================='''
import shutil
fig, ax = plt.subplots(figsize=(6.3,5))
for star in T_T:
    for root, dirs, files in os.walk('/Users/abelink/MEGA/PhD/programs/python/LCExtractor/DATA/'):
        for file in files:
            if file == star['ID']+'_stats.txt':
                f_dir = os.path.join(root, file)
                freqs, mags = np.loadtxt(f_dir, skiprows=6, delimiter=' ').T
                for freq,mag in zip(freqs,mags):
                    if mag == 1.0:
                        c='turquoise'
                    else: c='b'
                    ax.scatter(np.log10(star['Teff']),np.log10(1/freq), s=40*mag, marker='o', c=c)

ax.axhline(0.4, lw=0.5, c='gray')
ax.set_xlabel('log(Teff) [K]')
ax.set_ylabel('log Period(d)')
ax.set_xlim(4.55,3.7)
ax.set_ylim(0.,2.4)

fig.savefig('/Users/abelink/MEGA/PhD/programs/python/LCExtractor/ALL_PLOTS/Saio.png', format='png', dpi=300, bbox_inches='tight')
plt.show()


'''=============================================================================
        Fig. sigmaTp vs Teff
============================================================================='''
import shutil
fig, (ax1,ax2) = plt.subplots(2,1, figsize=(6,6))
for star in T_T:
    for root, dirs, files in os.walk('/Users/abelink/MEGA/PhD/programs/python/LCExtractor/DATA/'):
        for file in files:
            if file == star['ID']+'_stats.txt':
                f_dir = os.path.join(root, file)
                Std, PP = np.loadtxt(f_dir, skiprows=2, max_rows=1, delimiter=' ').T
                if star['ID'] in ['HD36486','HD91316','HD198478']: # SATURATED
                    continue
                if star['ID'] not in ['HD68450','HD192422','HD41398','HD60308','HD79186']:
                    continue
                ax1.scatter(np.log10(star['Teff']),Std, s=40, marker='o', c='b')
                ax2.scatter(np.log10(star['Teff']), PP, s=40, marker='o', c='b')

ax1.set_xlabel('log(Teff) [K]'); ax2.set_xlabel('log(Teff) [K]')
ax1.invert_xaxis(); ax2.invert_xaxis();
ax1.set_ylabel(r'$\sigma (T_{p})  [mmag]$')
ax2.set_ylabel(r'Peak to peak [mmag]')

fig.savefig('/Users/abelink/MEGA/PhD/programs/python/LCExtractor/ALL_PLOTS/std_pp.png', format='png', dpi=300, bbox_inches='tight')
plt.show()


'''=============================================================================
        Extra plot Geneva tracks
============================================================================='''
from models import *

fig, (ax1,ax2) = plt.subplots(2,1, figsize=(4,6)) #8,7 / 6,8
ax1.set_ylabel(r"log($\mathcal{L}$/$\mathcal{L}_{\odot}$)", size=12)
ax2.set_ylabel(r"log(L/L$_{\odot}$)", size=12)
ax2.set_xlabel(r"log(T$_{eff})\,$[K]", size=12)
ax1.set_xlim(4.8, 3.5); ax2.set_xlim(4.8, 3.5)

for i in [25,40]:
    trk = trackgene(i)
    trk = trk[trk['line'] < 210]
    ax1.plot(trk['log_Teff'], trk['log_Lspec'], color='b')
    ax1.text(trk['log_Teff'][0]+0.15, trk['log_Lspec'][0], str(i)+r'$\odot$', color='b', fontsize=10)
    ax2.text(trk['log_Teff'][0]+0.15, trk['log_L'][0], str(i)+r'$\odot$', color='r', fontsize=10)
    ax2.plot(trk['log_Teff'], trk['log_L'], color='r')
    #ax.set_ylim(3.3,4.5)
fig.savefig('/Users/abelink/MEGA/PhD/programs/python/LCExtractor/ALL_PLOTS/geneva.png', format='png', dpi=300, bbox_inches='tight')

plt.show()
