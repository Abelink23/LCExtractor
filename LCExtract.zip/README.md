# LCExtractor
Extracting Light-Curves from TESS and Kepler data in an easy way!
